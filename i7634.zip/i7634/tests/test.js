fixture('Resize test').page('https://devexpress.github.io/testcafe/example/')

test('resize window', async (t) => {
    await t
      .maximizeWindow()
      .debug();
  });
