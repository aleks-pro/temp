module.exports = {
    "src": "tests"
}